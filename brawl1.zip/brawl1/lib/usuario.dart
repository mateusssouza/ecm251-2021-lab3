class User{
  String nome = "nome";
  String senha = "senha";
  int numTrofeis = 1;

}