package com.example.brawl1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
